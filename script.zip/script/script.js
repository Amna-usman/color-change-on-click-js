
var btn=document.getElementsByTagName('button');
btn[0]
.addEventListener('click', function () {
   var head1=document.getElementById('Heading')
   head1.style.color="orange";
  

});

var a=10;
var b=12;

console.log("Sum is : " + a+b);


